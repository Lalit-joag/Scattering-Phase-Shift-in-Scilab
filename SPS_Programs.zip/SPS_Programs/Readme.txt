This is the readme file for execution of Scattering Phase Shift Programs
Please follow these steps :
Step-1. Copy or write this code directly into Scinotes windows.
Step-2. Save it with extension .sci
Step-3. Now execute this code window using function key 'F5' this automatically save and execute the program.
Step-4. Now in Console window type or simply copy function name and paste it here and press return.

 After run you will see Chisquare, MPE, Phase shift Experimental and simulated on the console window,
 also a figure window be visible to you.
 
  For further clarification please watch attached video.
